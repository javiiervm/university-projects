﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Globalization;

namespace library
{
    public class CADProduct
    {
        private string _constring;

        public CADProduct()
        {
            _constring = ConfigurationManager.ConnectionStrings["Database"].ToString();
        }

        /// <summary>
        /// Adds a new row to the database with the data contained in the element received by parameter.
        /// </summary>
        /// <param name="en"></param>
        /// <returns>True if the element was added to the table, false otherwise</returns>
        /// <exception cref="Exception"></exception>
        public bool Create(ENProduct en)
        {
            
            // Insert data into the database
            String commandStr = "INSERT INTO Products VALUES ('"
                                    + en.Name + "', '"
                                    + en.Code + "', "
                                    + en.Amount + ", "
                                    + en.Price+ ", "
                                    + en.Category + ", '"
                                    + en.CreationDate + "');";

            SqlConnection conn = null;

            try
            {
                conn = new SqlConnection(this._constring);
                conn.Open();
                SqlCommand sqlCmd = new SqlCommand(commandStr, conn);
                sqlCmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw new Exception("Error añadiendo el producto: " + en.Name, ex);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
            return true;
        }

        /// <summary>
        /// Uses a (GIVEN) id to update values of that row in the database to the 
        /// ones from the element received as a parameter
        /// </summary>
        /// <param name="en"></param>
        /// <returns>True if the element was updated, false otherwise</returns>
        /// <exception cref="Exception"></exception>
        public bool Update(ENProduct en)
        {

            String commandStr = "UPDATE Products SET "
                                    + "name = '" + en.Name + "', "
                                    + "amount = " + en.Amount + ", "
                                    + "price = " + en.Price + ", "
                                    + "category = " + en.Category + ", "
                                    + "creationDate = '" + en.CreationDate + "' "
                                    + "WHERE code = '" + en.Code + "';";

            SqlConnection conn = null;

            try
            {
                conn = new SqlConnection(this._constring);
                conn.Open();
                SqlCommand sqlCmd = new SqlCommand(commandStr, conn);
                sqlCmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw new Exception("Error actualizando el producto: " + en.Name, ex);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }

            return true;
        }


        /// <summary>
        /// Deletes the row containing the data from the element received as a parameter from the database
        /// </summary>
        /// <param name="en"></param>
        /// <returns>True if the element could be deleted from the table, false otherwise</returns>
        /// <exception cref="Exception"></exception>
        public bool Delete(ENProduct en)
        {
            
            // No id needed but it would make things a lot easier
            String commandStr = "DELETE FROM Products WHERE "
                                    + "name = '" + en.Name + "' AND "
                                    + "code = '" + en.Code + "' AND "
                                    + "amount = " + en.Amount + " AND "
                                    + "price = " + en.Price + " AND "
                                    + "category = " + en.Category + " AND "
                                    + "creationDate = '" + en.CreationDate + "';";

            SqlConnection conn = null;

            try
            {
                conn = new SqlConnection(this._constring);
                conn.Open();
                SqlCommand sqlCmd = new SqlCommand(commandStr, conn);
                sqlCmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw new Exception("Error actualizando el producto: " + en.Name, ex);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
            return true;
        }

        /// <summary>
        /// Checks the database to see if the element received by parameter exists or not
        /// </summary>
        /// <param name="en"></param>
        /// <returns>True if the element was found in the table, false otherwise</returns>
        /// <exception cref="Exception"></exception>
        public bool Read(ENProduct en)
        {
            bool result = false;

            SqlCommand command = null;

            SqlConnection conn = null;
            SqlDataReader dataReader = null;

            try
            {
                conn = new SqlConnection(this._constring);
                conn.Open();

                command = new SqlCommand("SELECT * FROM Products WHERE "
                                    + "name = @name AND "
                                    + "code = @code AND "
                                    + "amount = @amt AND "
                                    + "price = @price AND "
                                    + "category = @category AND "
                                    + "creationDate = @creationDate;", conn);

                command.Parameters.AddWithValue("@name", en.Name);
                command.Parameters.AddWithValue("@code", en.Code);
                command.Parameters.AddWithValue("@amt", en.Amount);
                command.Parameters.AddWithValue("@price", en.Price);
                command.Parameters.AddWithValue("@category", en.Category);
                command.Parameters.AddWithValue("@creationDate", en.CreationDate);

                dataReader = command.ExecuteReader();
                result = dataReader.Read();
            }
            catch (SqlException ex)
            {
                throw new Exception("Error actualizando el producto: " + en.Name, ex);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }

            return result;
        }

        /// <summary>
        /// Reads the first element from the table (the one with id == 0) and returns it by parameter.
        /// For this purpose, the method's signature was changed to use ref with the parameter.
        /// </summary>
        /// <param name="en"></param>
        /// <returns>True if the table contains data (first element can be found), false otherwise</returns>
        /// <exception cref="Exception"></exception>
        public bool ReadFirst(ENProduct en)
        {
            bool result = false;

            SqlCommand command = null;

            SqlConnection conn = null;
            SqlDataReader dataReader = null;

            try
            {
                conn = new SqlConnection(this._constring);
                conn.Open();
                command = new SqlCommand("SELECT * FROM Products", conn);
                dataReader = command.ExecuteReader();
                result = dataReader.Read();

                if (result)
                {
                    // First row in the table will be first result returned by .Read()
                    en.Name = (String)dataReader["name"];
                    en.Code = (String)dataReader["code"];
                    en.Amount = (int)dataReader["amount"];
                    en.Price = (float)(double)dataReader["price"];
                    en.Category = (int)dataReader["category"];
                    en.CreationDate = dataReader.GetDateTime(6);
                }
            }
            catch (SqlException ex)
            {
                throw new Exception("Error actualizando el producto: " + en.Name, ex);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
            return result;
        }

        /// <summary>
        /// Reads an id for the row in the table where the data is the same as for the element received by
        /// parameter. After that, it uses the id to read (and return by parameter) the element in the database
        /// with an id that is 1 more than the id read.
        /// </summary>
        /// <param name="en"></param>
        /// <returns>True if the next element was found in the table, false otherwise</returns>
        /// <exception cref="Exception"></exception>
        public bool ReadNext(ENProduct en)
        {
            bool result = false;

            SqlCommand command = null;
            SqlConnection conn = null;

            try
            {
                conn = new SqlConnection(this._constring);
                conn.Open();

                command = new SqlCommand("SELECT * FROM Products", conn); 

                SqlDataReader dataReader = command.ExecuteReader();

                // Executed whilst there are rows to read
                while (dataReader.Read())
                {
                    // If the element 'en' is found, read the next one and save it
                    if ((String)dataReader["name"] == en.Name
                        && (String)dataReader["code"] == en.Code
                        && (int)dataReader["amount"] == en.Amount
                        && (float)(double)dataReader["price"] == en.Price
                        && (int)dataReader["category"] == en.Category
                        && dataReader.GetDateTime(6) == en.CreationDate)
                    {
                        if (dataReader.Read())
                        {
                            en.Name = (String)dataReader["name"];
                            en.Code = (String)dataReader["code"];
                            en.Amount = (int)dataReader["amount"];
                            en.Price = (float)(double)dataReader["price"];
                            en.Category = (int)dataReader["category"];
                            en.CreationDate = dataReader.GetDateTime(6);

                            result = true;
                            break;
                        }

                    }
                }
            }
            catch (SqlException ex)
            {
                throw new Exception("Error actualizando el producto: " + en.Name, ex);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
            return result;
        }


        /// <summary>
        /// Does the same as ReadNext but reads an element with an id that is 1 less than the element asked for
        /// </summary>
        /// <param name="en"></param>
        /// <returns>True if the previous element was found in the table, false otherwise</returns>
        /// <exception cref="Exception"></exception>
        public bool ReadPrev(ENProduct en)
        {
            bool result = false;

            ENProduct previous = null;
            SqlConnection conn = null;
            SqlCommand command = null;

            try
            {
                conn = new SqlConnection(this._constring);
                conn.Open();
                SqlDataReader dataReader = null;

                command = new SqlCommand("SELECT * FROM Products", conn);

                dataReader = command.ExecuteReader();
                dataReader.Read();
                previous = new ENProduct((String)dataReader["code"],
                                   (String)dataReader["name"],
                                   (int)dataReader["amount"],
                                   (float)(double)dataReader["price"],
                                   (int)dataReader["category"],
                                   dataReader.GetDateTime(6));
                
                while (dataReader.Read())
                {
                    if ((String)dataReader["name"] == en.Name
                        && (String)dataReader["code"] == en.Code
                        && (int)dataReader["amount"] == en.Amount
                        && (float)(double)dataReader["price"] == en.Price
                        && (int)dataReader["category"] == en.Category
                        && dataReader.GetDateTime(6) == en.CreationDate)
                    {
                        en.Name = previous.Name;
                        en.Code = previous.Code;
                        en.Amount = previous.Amount;
                        en.Price = previous.Price;
                        en.Category = previous.Category;
                        en.CreationDate = previous.CreationDate;

                        result = true;
                        break;
                    }

                    previous = new ENProduct((String)dataReader["code"],
                                   (String)dataReader["name"],
                                   (int)dataReader["amount"],
                                   (float)(double)dataReader["price"],
                                   (int)dataReader["category"],
                                   dataReader.GetDateTime(6));
                }
            }
            catch (SqlException ex)
            {
                throw new Exception("Error actualizando el producto: " + en.Name, ex);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }

            return result;
        }
    }
}

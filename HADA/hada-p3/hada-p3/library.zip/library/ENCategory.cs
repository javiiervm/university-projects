﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    // This class represents the "Category" entity and provides methods to interact with the database through CADCategory
    public class ENCategory
    {
        // Private field to store the name of the category
        private String _name;

        // Public property to access or modify the category name
        public String Name
        {
            get
            {
                return _name; // Getter returns the category name
            }
            set
            {
                _name = value; // Setter assigns a new value to the category name
            }
        }

        // Constructor that initializes the ENCategory with a given name
        public ENCategory(String name)
        {
            Name = name;
        }

        // Method to read the category from the database using its name
        public bool read()
        {
            try
            {
                // Create a new CADCategory instance and attempt to read this category from the database
                CADCategory cad = new CADCategory();
                return cad.read(this);
            }
            catch (SqlException ex)
            {
                // If a SQL-related error occurs, return false
                return false;
            }
            catch (Exception ex)
            {
                // If an unexpected error occurs, return false
                return false;
            }
        }

        // Static method to read all categories from the database
        public static List<ENCategory> readAll()
        {
            try
            {
                // Create a new CADCategory instance and return all categories
                CADCategory cad = new CADCategory();
                return cad.readAll();
            }
            catch (SqlException ex)
            {
                // If a SQL-related error occurs, return an empty list
                return new List<ENCategory>();
            }
            catch (Exception ex)
            {
                // If an unexpected error occurs, return an empty list
                return new List<ENCategory>();
            }
        }

    }
}
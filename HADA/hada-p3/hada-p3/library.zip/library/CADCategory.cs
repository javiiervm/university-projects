﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    // This class handles database operations related to categories (reading one or all categories)
    public class CADCategory
    {
        // Connection string to the SQL Server database
        private string _constring;

        // Constructor: initializes the connection string from the config file
        public CADCategory()
        {
            // Retrieves the connection string named "Database" from the config file
            _constring = ConfigurationManager.ConnectionStrings["Database"].ToString();
        }

        // Method to read a specific category from the database using its name
        public bool read(ENCategory en)
        {
            bool result = false; // Will be true if the category is found in the DB

            SqlCommand command = null;           // Command to send to SQL Server
            SqlConnection conn = null;           // Connection to the SQL Server
            SqlDataReader dataReader = null;     // Used to read the result of the query

            try
            {
                // Create and open the database connection
                conn = new SqlConnection(this._constring);
                conn.Open();

                // Define the SQL query to find the category by name (parameterized to prevent SQL injection)
                command = new SqlCommand("SELECT * FROM Categories WHERE name = @name", conn);

                // Set the parameter value
                command.Parameters.AddWithValue("@name", en.Name);

                // Execute the query and get the result
                dataReader = command.ExecuteReader();

                // Read() returns true if at least one record is found
                result = dataReader.Read();
            }
            catch (SqlException ex)
            {
                // If there's a SQL error, throw a new exception with more context
                throw new Exception("Error reading the product: " + en.Name, ex);
            }
            catch (Exception ex)
            {
                // Rethrow any other exception
                throw ex;
            }
            finally
            {
                // Always close the connection if it was opened
                if (conn != null)
                {
                    conn.Close();
                }
            }

            // Return true if the category was found, false otherwise
            return result;
        }

        // Method to read all categories from the database
        public List<ENCategory> readAll()
        {
            // List to hold all the categories read from the database
            List<ENCategory> list = new List<ENCategory>();

            SqlCommand command = null;       // SQL command to execute
            SqlConnection conn = null;       // Database connection

            try
            {
                // Open the connection to the database
                conn = new SqlConnection(this._constring);
                conn.Open();

                // SQL query to select all rows from the Categories table
                command = new SqlCommand("SELECT * FROM Categories", conn);

                // Execute the query and obtain the result set
                SqlDataReader dataReader = command.ExecuteReader();

                // Iterate through each row of the result
                while (dataReader.Read())
                {
                    // Create a new ENCategory using the "name" field from the current row
                    ENCategory category = new ENCategory((String)dataReader["name"]);

                    // Add the category to the result list
                    list.Add(category);
                }
            }
            catch (SqlException ex)
            {
                // If a SQL error occurs, throw a generic exception with the original one as inner
                throw new Exception("", ex);
            }
            catch (Exception ex)
            {
                // Rethrow any other exception
                throw ex;
            }
            finally
            {
                // Ensure the connection is closed after operations are complete
                if (conn != null)
                {
                    conn.Close();
                }
            }

            // Return the list of all categories
            return list;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    /// <summary>
    /// Business logic class that represents a product in the library system.
    /// Encapsulates the product's data and provides methods to interact with the data access layer (CADProduct).
    /// </summary>
    public class ENProduct
    {
        // Private fields to store property values
        private string code;
        private string name;
        private int amount;
        private float price;
        private DateTime creationDate;
        private int category;

        /// <summary>
        /// Product code. Must be between 1 and 16 characters.
        /// </summary>
        public string Code
        {
            get => code;
            set
            {
                if (value.Length < 1 || value.Length > 16)
                    throw new ArgumentException("Code length must be 1-16 chars!");
                code = value;
            }
        }

        /// <summary>
        /// Product name. Maximum length is 32 characters.
        /// </summary>
        public string Name
        {
            get => name;
            set
            {
                if (value.Length > 32)
                    throw new ArgumentException("Name length must be max 32 chars!");
                name = value;
            }
        }

        /// <summary>
        /// Product amount. Must be between 0 and 9999.
        /// </summary>
        public int Amount
        {
            get => amount;
            set
            {
                if (value < 0 || value > 9999)
                    throw new ArgumentException("Amount must be 0-9999!");
                amount = (int)value;
            }
        }

        /// <summary>
        /// Product price. Must be between 0 and 9999.99. Value is rounded before storage.
        /// </summary>
        public float Price
        {
            get => price;
            set
            {
                if (value < 0 || value > 9999.99)
                    throw new ArgumentException("Price must be 0-9999.99!");
                price = (float)Math.Round(value);
            }
        }

        /// <summary>
        /// Date the product was created. Must not be before DateTime.MinValue.
        /// </summary>
        public DateTime CreationDate
        {
            get => creationDate;
            set
            {
                if (value < DateTime.MinValue)
                    throw new ArgumentException("Invalid date!");
                creationDate = value;
            }
        }

        /// <summary>
        /// Product category. Must be in the range [1, 4].
        /// </summary>
        public int Category
        {
            get => category;
            set
            {
                if (value < 1 || value > 4)
                {
                    throw new ArgumentException("Category must be 1-4! And it is " + value);
                }
                category = value;
            }
        }

        /// <summary>
        /// Default constructor. Initializes all properties with default values.
        /// </summary>
        public ENProduct()
        {
            this.code = "";
            this.name = "";
            this.amount = 0;
            this.price = 0;
            this.creationDate = DateTime.Now;
            this.category = 0;
        }

        /// <summary>
        /// Full constructor. Initializes all product attributes with provided values.
        /// </summary>
        public ENProduct(string code, string name, int amount, float price, int category, DateTime creationDate)
        {
            this.Code = code;
            this.Name = name;
            this.Amount = amount;
            this.Price = price;
            this.CreationDate = creationDate;
            this.Category = category;
        }

        /// <summary>
        /// Calls the CADProduct.Create method to insert this product into the database.
        /// </summary>
        /// <returns>True if successful, false otherwise.</returns>
        public bool Create()
        {
            try
            {
                CADProduct cad = new CADProduct();
                return cad.Create(this);
            }
            catch (SqlException ex)
            {
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        /// <summary>
        /// Calls the CADProduct.Update method to update this product in the database.
        /// </summary>
        public bool Update()
        {
            try
            {
                CADProduct cad = new CADProduct();
                return cad.Update(this);
            }
            catch (SqlException ex)
            {
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        /// <summary>
        /// Calls the CADProduct.Delete method to remove this product from the database.
        /// </summary>
        public bool Delete()
        {
            try
            {
                CADProduct cad = new CADProduct();
                return cad.Delete(this);
            }
            catch (SqlException ex)
            {
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        /// <summary>
        /// Calls the CADProduct.Read method to load product data based on the current object's primary key.
        /// </summary>
        public bool Read()
        {
            try
            {
                CADProduct cad = new CADProduct();
                return cad.Read(this);
            }
            catch (SqlException ex)
            {
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        /// <summary>
        /// Loads the first product record from the database.
        /// </summary>
        public bool ReadFirst()
        {
            try
            {
                CADProduct cad = new CADProduct();
                return cad.ReadFirst(this);
            }
            catch (SqlException ex)
            {
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        /// <summary>
        /// Loads the next product record relative to the current one.
        /// </summary>
        public bool ReadNext()
        {
            try
            {
                CADProduct cad = new CADProduct();
                return cad.ReadNext(this);
            }
            catch (SqlException ex)
            {
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        /// <summary>
        /// Loads the previous product record relative to the current one.
        /// </summary>
        public bool ReadPrev()
        {
            try
            {
                CADProduct cad = new CADProduct();
                return cad.ReadPrev(this);
            }
            catch (SqlException ex)
            {
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
﻿
<%@ Page Title="Home Page" Language="C#" MasterPageFile="~/Site1.Master" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="proWeb._Default" %>

<asp:Content ID="BodyContent" ContentPlaceHolderID="MainContent" runat="server">

    <h2>Products management</h2><br />
    <div>
        Code &nbsp;&nbsp;
        <asp:TextBox ID="TextBoxCode" runat="server"></asp:TextBox><br /><br />
        
        Name &nbsp;&nbsp;
        <asp:TextBox ID="TextBoxName" runat="server"></asp:TextBox><br /><br />
        
        Amount &nbsp;&nbsp;
        <asp:TextBox ID="TextBoxAmount" runat="server"></asp:TextBox><br /><br />
        
        Category &nbsp;&nbsp;
        <asp:DropDownList ID="DropDownListCategory" runat="server">
        </asp:DropDownList><br /><br />
        
        Price &nbsp;&nbsp;
        <asp:TextBox ID="TextBoxPrice" runat="server"></asp:TextBox><br /><br />
        
        Creation date &nbsp;&nbsp;
        <asp:TextBox ID="TextBoxCreationDate" runat="server"></asp:TextBox><br /><br />
        
        <asp:RegularExpressionValidator ID="DateRegularExpressionValidator" 
                runat="server" 
                ForeColor="Red"
                ErrorMessage=" Invalid date format, please use dd/MM/yyyy HH:mm:ss"
                ValidationExpression="^(0[1-9]|[1-2][0-9]|3[0,1])\/(0[1-9]|1[0,1,2])\/(\d{2}[0-9][0-9])\s([0,1][0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$"
                ControlToValidate="TextBoxCreationDate"
                Display="Dynamic"></asp:RegularExpressionValidator>

        <asp:RegularExpressionValidator ID="CodeRegularExpressionValidator" 
                runat="server" 
                ForeColor="Red"
                ErrorMessage=" Code must be between 1 and 16 characters long"
                ValidationExpression="^[0-9,a-z,A-Z]{1,16}$"
                ControlToValidate="TextBoxCode"
                Display="Dynamic"></asp:RegularExpressionValidator>

        <asp:RegularExpressionValidator ID="NameRegularExpressionValidator" 
                runat="server" 
                ForeColor="Red"
                ErrorMessage=" Name can only be 32 characters long"
                ValidationExpression="^[\s,0-9,a-z,A-Z]{0,32}$"
                ControlToValidate="TextBoxName"
                Display="Dynamic"></asp:RegularExpressionValidator>

        <asp:RegularExpressionValidator ID="AmountRegularExpressionValidator" 
                runat="server" 
                ForeColor="Red"
                ErrorMessage=" Amount should be between 0-9999"
                ValidationExpression="^[0-9]{0,4}$"
                ControlToValidate="TextBoxAmount"
                Display="Dynamic"></asp:RegularExpressionValidator>
        <asp:RegularExpressionValidator ID="PriceRegularExpressionValidator" 
                runat="server" 
                ForeColor="Red"
                ErrorMessage=" Price should be between 0-9999.99"
                ValidationExpression="^([0-9]{0,4}|[0-9]{0,4}\.[0-9]{1,2})$"
                ControlToValidate="TextBoxPrice"
                Display="Dynamic"></asp:RegularExpressionValidator>
    </div>
    <div>
        <asp:Label ID="StatusLabel" runat="server" Text="" Display="Dynamic"></asp:Label>
    </div>

    <asp:Button ID="ButtonCreate" runat="server" Text="Create" OnClick="ButtonCreateFunction"/>&nbsp;
    <asp:Button ID="ButtonUpdate" runat="server" Text="Update" OnClick="ButtonUpdateFunction" />&nbsp;
    <asp:Button ID="ButtonDelete" runat="server" Text="Delete" OnClick="ButtonDeleteFunction" />&nbsp;
    <asp:Button ID="ButtonRead" runat="server" Text="Read" OnClick="ButtonReadFunction" />&nbsp;
    <asp:Button ID="ButtonFirst" runat="server" Text="Read First" OnClick="ButtonFirstFunction" />&nbsp;
    <asp:Button ID="ButtonPrev" runat="server" Text="Read Prev" OnClick="ButtonPrevFunction" />&nbsp;
    <asp:Button ID="ButtonNext" runat="server" Text="Read Next" OnClick="ButtonNextFunction" />&nbsp;

    

</asp:Content>

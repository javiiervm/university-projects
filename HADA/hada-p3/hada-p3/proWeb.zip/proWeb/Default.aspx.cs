﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using library;
using System.Globalization;
using System.Drawing;
using System.Threading.Tasks;
using System.Diagnostics;

namespace proWeb
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Stores the last index selected for after updating categories
            int selectedIndex = DropDownListCategory.SelectedIndex;

            DropDownListCategory.Items.Clear();     // Clears dropdownlist in case there was something before
            List<ENCategory> categoryList = ENCategory.readAll();
            Debug.Write(categoryList.Count);
            for (int i=0; i<categoryList.Count; i++)
            {
                DropDownListCategory.Items.Add(categoryList[i].Name);
            }

            DropDownListCategory.SelectedIndex = selectedIndex;
        }

        protected void DisplayReadProduct(ENProduct en)
        {
            TextBoxCode.Text = en.Code;
            TextBoxName.Text = en.Name;
            TextBoxAmount.Text = en.Amount.ToString();
            DropDownListCategory.SelectedIndex = en.Category - 1;
            TextBoxPrice.Text = en.Price.ToString();
            TextBoxCreationDate.Text = en.CreationDate.ToString("dd/MM/yyyy HH:mm:ss");
        }

        // SelectedIndex always uses + 1 to match the ID of the categories in the table (1-4)

        protected void DisplayMessage(String operationType, bool result, bool query = false)
        {
            String output = "";
            Color textColor = new Color();
            if (query)
            {
                if (result)
                {
                    output = "Object was found in the database";
                    textColor = Color.FromArgb(0, 255, 0);
                }
                else
                {
                    output = "Object was not found in the database";
                    textColor = Color.FromArgb(255, 0, 0);
                }
            } else
            {
                if(result)
                {
                    output = operationType + " operation performed succesfully!";
                    textColor = Color.FromArgb(0, 255, 0);
                } else
                {
                    output = operationType + " operation failed!";
                    textColor = Color.FromArgb(255, 0, 0);
                }
            }

            StatusLabel.ForeColor = textColor;
            StatusLabel.Text = output;
        }

        protected void ButtonCreateFunction(object sender, EventArgs e)
        {
            ENProduct enProduct = new ENProduct(TextBoxCode.Text, TextBoxName.Text, Int32.Parse(TextBoxAmount.Text), float.Parse(TextBoxPrice.Text), DropDownListCategory.SelectedIndex + 1, DateTime.ParseExact(TextBoxCreationDate.Text, "dd/MM/yyyy HH:mm:ss", CultureInfo.CurrentCulture));
            DisplayMessage("Create", enProduct.Create());
        }
        protected void ButtonUpdateFunction(object sender, EventArgs e)
        {
            ENProduct enProduct = new ENProduct(TextBoxCode.Text, TextBoxName.Text, Int32.Parse(TextBoxAmount.Text), float.Parse(TextBoxPrice.Text), DropDownListCategory.SelectedIndex + 1, DateTime.ParseExact(TextBoxCreationDate.Text, "dd/MM/yyyy HH:mm:ss", CultureInfo.CurrentCulture));
            DisplayMessage("Update", enProduct.Update());
        }
        protected void ButtonDeleteFunction(object sender, EventArgs e)
        {
            ENProduct enProduct = new ENProduct(TextBoxCode.Text, TextBoxName.Text, Int32.Parse(TextBoxAmount.Text), float.Parse(TextBoxPrice.Text), DropDownListCategory.SelectedIndex + 1, DateTime.ParseExact(TextBoxCreationDate.Text, "dd/MM/yyyy HH:mm:ss", CultureInfo.CurrentCulture));
            DisplayMessage("Delete", enProduct.Delete());
        }
        protected void ButtonReadFunction(object sender, EventArgs e)
        {
            ENProduct enProduct = new ENProduct(TextBoxCode.Text, TextBoxName.Text, Int32.Parse(TextBoxAmount.Text), float.Parse(TextBoxPrice.Text), DropDownListCategory.SelectedIndex + 1, DateTime.ParseExact(TextBoxCreationDate.Text, "dd/MM/yyyy HH:mm:ss", CultureInfo.CurrentCulture));
            DisplayMessage("Read", enProduct.Read(), true);
        }
        protected void ButtonFirstFunction(object sender, EventArgs e)
        {
            ENProduct enProduct = new ENProduct();
            DisplayMessage("Read", enProduct.ReadFirst(), true);
            DisplayReadProduct(enProduct);
        }
        protected void ButtonPrevFunction(object sender, EventArgs e)
        {
            ENProduct enProduct = new ENProduct(TextBoxCode.Text, TextBoxName.Text, Int32.Parse(TextBoxAmount.Text), float.Parse(TextBoxPrice.Text), DropDownListCategory.SelectedIndex + 1, DateTime.ParseExact(TextBoxCreationDate.Text, "dd/MM/yyyy HH:mm:ss", CultureInfo.CurrentCulture));
            DisplayMessage("Read", enProduct.ReadPrev(), true);
            DisplayReadProduct(enProduct);
        }
        protected void ButtonNextFunction(object sender, EventArgs e)
        {
            ENProduct enProduct = new ENProduct(TextBoxCode.Text, TextBoxName.Text, Int32.Parse(TextBoxAmount.Text), float.Parse(TextBoxPrice.Text), DropDownListCategory.SelectedIndex + 1, DateTime.ParseExact(TextBoxCreationDate.Text, "dd/MM/yyyy HH:mm:ss", CultureInfo.CurrentCulture));
            DisplayMessage("Read", enProduct.ReadNext(), true);
            DisplayReadProduct(enProduct);
        }
    }
}